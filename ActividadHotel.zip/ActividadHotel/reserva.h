#include <iostream>
#include <string>
#include <deque>
using namespace std;
#ifndef __RESERVA_H
#define __RESERVA_H
#include "huesped.h"
class Reserva{
    public:
        Huesped cliente;
        hotel num;
        int num_noches;
        Reserva();
        Reserva(hotel num,Huesped cliente,int num_noches);
        int total();
        void detalles_reserva();
        void cancelar_reserva();
};
#endif
