#include <iostream>
#include "the_forest.h"
#include "habitacion.h"
#include "huesped.h"
#include "reserva.h"
#include "pago.h"
#include <iostream>
#include <string>


// Intengrantes: Ana gabriela Argüello, Laura Isabel Olivero, Santiago Salazar, Laura Lozano, Juan David Vasquez
using namespace std;
int main() {
    string name= "Der Wald";
    hotel hotel(name);
    Reserva si;
    bool flag=1;

    int pri;
    cout << "                          W   W   EEEEE   L      CCCC   OOO    M   M   EEEEE\n";
    cout << "                          W   W   E       L     C      O   O   MM MM   E    \n";
    cout << "                          W W W   EEE     L     C      O   O   M M M   EEE  \n";
    cout << "                          W W W   E       L     C      O   O   M   M   E    \n";
    cout << "                           W W    EEEEE   LLLLL  CCCC   OOO    M   M   EEEEE\n\n";

    cout << "                                          TTTTT    OOO\n"
         << "                                            T     O   O\n"
         << "                                            T     O   O\n"
         << "                                            T     O   O\n"
         << "                                            T      OOO\n\n\n";
    cout << "                                                *    \n"
         << "                                               ***   \n"
         << "                                              *****  \n"
         << "                                             ******* \n"
         << "                                            *********\n"
         << "                                                |    \n\n";
    cout << "                      DDDDD   EEEE   RRRRR       W     W    AAA    L      DDDDD  \n"
         << "                      D   D   E      R   R       W     W   A   A   L      D   D  \n"
         << "                      D   D   EEE    RRRRR       W  W  W   AAAAA   L      D   D  \n"
         << "                      D   D   E      R  R         W W W    A   A   L      D   D  \n"
         << "                      DDDDD   EEEE   R   R         W W    A     A  LLLLL  DDDDD  \n\n\n";
    while(flag!=0){
        printf("\nBienvenido al Hotel Der Wald\n En que le podemos ayudar?\n 1. Reservar\n 2. Check-Out\n 3. Cancelar Reserva 4. salir\n Elige una opcion : ");
        cin>>pri;
        if (pri==1){
            string name="",phone="",correo="";
            int habi,noches;
            printf("Para continuar con la reserva porfavor digite los siguientes datos:\n1. Nombre = ");
            cin>>name;
            printf("2. Numero de telefono(sin espacios) = "); //aca tm se puede usar el getLine para que permita los espacio
            cin>>phone;
            printf("3. Correo Electronico(sin espacios) = ");
            cin>>correo;
            printf("Numero de noches = ");
            cin>>noches;
            int revi=hotel.revi_dispo(),precio_habi,dinero_huesped;
            if(revi!=0){
                printf("Elige la habitacion\n");
                hotel.mostrar_habitaciones();
                printf("Numero de habitacion que desea = ");
                cin>>habi;
                //Habitacion room(habi);
                hotel.reserva_habitacion(habi);
                precio_habi=hotel.ver_precio(habi);
                Huesped per(habi,name,phone,correo);
                int logro= per.realizar_pago(per.money,precio_habi);
                Reserva res(hotel,per,noches);
                if(logro==1){
                    printf("\nEstos son los detalles de tu reserva= \n");
                    res.detalles_reserva();
                    res.cliente.realizar_pago(cliente.money, Habitacion.precio);
                }
                si = res;
            }else{
                printf("No hay habitaciones disponibles");
            }
            
        }else if(pri==2){
            int num;
            printf("Numero de habitacion= ");
            cin>> num;
            int si = hotel.checkout(num);
            if(si==1){
                printf("Danke!, Esperamos que vuelva pronto\nBuen Viaje");
            }
        }else if(pri==3){
            //aca se cancela lo del hotel 
            si.cancelar_reserva();
        }else if(pri == 4){
            flag = 0;
            printf("Gracias por preferirnos!! ");
        }
        else{
            printf("LO LAMENTAMOS, PERO ESA OPCION NO SE ENCUENTRA DISPONIBLE");
        }

    }

    return 0;
}
