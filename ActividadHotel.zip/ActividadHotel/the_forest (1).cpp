#include "the_forest.h"
#include "habitacion.h"
#include "huesped.h"
#include "reserva.h"
#include "pago.h"
#include <iostream>
#include <string>
#include <string.h>
#include <cstdlib>
#include <ctime>
using namespace std;


Huesped::Huesped(){}

Habitacion::Habitacion(){}

Reserva::Reserva(){}

hotel::hotel(){}

Huesped::Huesped(int a, string name,string num,string correo){
    srand(static_cast<unsigned>(time(0)));
    int r =rand() % 501 + 500;

    this -> bedroom = a;
    this ->name = name;
    this ->money = r;
    this ->phone = "1234568738";
    this ->correo= correo;
}

Habitacion::Habitacion(int num){
    this->ocu = true;
    this->numero_dormitorio = num;
    this-> precio = 0;
}

Reserva::Reserva(hotel num,Huesped cli,int noches){
    this ->num = num;
    this ->cliente =   cli ;
    this -> num_noches = noches;
}


int Reserva::total(){
    int ans=num.ver_precio(cliente.bedroom),noche= num_noches;
    ans*=noche; // se va a pensar que el costo es por la noches entonces se multiplica por el numero de noches y eso da el monto total
    return ans;

}
void Reserva::cancelar_reserva(){
    num.rooms[cliente.bedroom-100].ocu= true; //el -100 es porque asi encuentro la habitacion del huesped y cambiar su ocupacion
    cliente.money+=num.ver_precio(cliente.bedroom);
    cout<<"Se rembolso el dinero\nDinero= "<<cliente.money<<endl;
}

void Reserva::detalles_reserva(){
    cout<<"Nombre de huesped= "<<cliente.name<<endl;
    cout<<"Telefono asociado= "<<cliente.phone<<endl;
    cout<<"Correo electronico= "<<cliente.correo<<endl;
    cout<<"Numero de dormitorio seleccionado= "<<cliente.bedroom<<endl;
}

// void Pago::realizar_pago(int monto,Reserva res){
//     int paga,noches,yo;
//     noches= res.num_noches;
//     paga= res.total(noches,monto);
//     if(res.cliente.money>paga){
//         res.cliente.money-=paga;
//         printf("\nLOGRASTE RESERVAR\n");
//     }else{
//         printf("NO TIENES SUFICIENTE DINERO PARA LA HABITACION");
//     }
    
// }
int Huesped::realizar_pago(int &dis,int ale) {
    int ans=1;
    if(dis>ale){
        cout<<"Este es tu monto actual= "<<dis<<endl;
        dis -= ale;
        cout<<"Te quedo este monto= "<<dis<<endl;
        printf("lOGRASTE RESERVAR");
    }else{
        printf("No tienes suficiente dinero para la habitacion\n");
        ans=0;
    }
    return ans;
}

hotel::hotel(string n) {
    this->name = n;
    this->adress = "Calle 5, Republica de los centauros";
    this->free_rooms = 10;
    for(int i = 0; i < 10; i++){
        srand(time(0));
        int r =rand() % 501 + 500;
        int num =  100 + i;
        this->rooms.push_back(Habitacion(num));
        rooms[i].precio = r-i;
    }
};

int hotel::revi_dispo() const{
    return free_rooms;
}

void hotel::reserva_habitacion(int a) {

    for(int i = 0; i < 10; i++){
        if(rooms[i].numero_dormitorio == a) {
            rooms[i].ocu = false;

        }
    }
    free_rooms -= 1;
}

void hotel::mostrar_habitaciones() {
    for(int i = 0; i < 10; i++){
        if(rooms[i].ocu == true){
            printf("Esta es la habitacion %d\n", rooms[i].numero_dormitorio);
            printf("El precio de esta habitacion es de $ %d", rooms[i].precio);
            printf("\n_______________________________\n___________________________________\n");

        }
    }
}

/*void hotel::checkout(int a) {
    int i=0;
    bool flag=true;
    while((i<10)&&(flag=true)){

        if((rooms[i].numero_dormitorio == a)){
                rooms[i].ocu = true;
                flag=false;
        }
        /*if( (rooms[i].numero_dormitorio == a) && (rooms[i].ocu== true)){
            printf("La habitacion no se encuentra ocupada");
            flag=false;
        i++;
        }

    }*/
int hotel::checkout(int a) {
    int ans= 1;
    for(int i = 0; i < 10; i++) {
        if ((rooms[i].numero_dormitorio == a)&&(rooms[i].ocu == false)) {
            rooms[i].ocu = true;
        }else if((rooms[i].numero_dormitorio == a)&&(rooms[i].ocu == true)){
            printf("La habitacion no se encuentra ocupada");
            ans = 0;
        }
    }
    return ans;
}


//void Huesped::pagar(int v) {
//    money-= v;
//}



int hotel:: ver_precio(int n){
    int i = 0, ans;
    bool flag = false;
    while((i< 10) && (flag != true)){
        if(rooms[i].numero_dormitorio == n){
            ans = rooms[i].precio;
            flag = true;
        }
        i++;
}
}

