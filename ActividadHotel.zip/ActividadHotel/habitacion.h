#include <iostream>
#include <string>
#include <deque>
using namespace std;
#ifndef __HABITACION_H
#define __HABITACION_H

class Habitacion{
public:
    bool ocu;
    int numero_dormitorio;
    int precio;
    Habitacion();
    Habitacion(int num);
    bool habi_dispo();

};
#endif
