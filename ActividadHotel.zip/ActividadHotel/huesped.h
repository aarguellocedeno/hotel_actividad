//
// Created by isabe on 5/08/2023.
//
#include "the_forest.h"
#include "habitacion.h"
#ifndef __HUESPED_H
#define __HUESPED_H
class Huesped{
    public:
    int money;
    string phone,correo,name;
    int bedroom;
    Huesped();
    Huesped(int a,string name,string tel,string correo);
    int realizar_pago(int &dis,int ale);
};


#endif

