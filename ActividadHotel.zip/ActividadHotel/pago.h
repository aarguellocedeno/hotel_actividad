#include <iostream>
#include <string>
#include <deque>
using namespace std;
#ifndef __PAGO_H
#define __PAGO_H
#include "reserva.h"

class Pago{
    Huesped person(int a,string name,string tel);
    hotel room;
    
    int monto;
    string fecha_ago;
    Reserva res(hotel room,Huesped person,int num_noches);
    int buscar_monto();
    void realizar_pago(int monto,Reserva res);
    //void realizar_pago(Habitacion room,int num_noches);
    

};
#endif