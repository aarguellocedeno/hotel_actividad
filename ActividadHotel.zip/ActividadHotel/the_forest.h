/*created date: 5/08/2023.
Created by Laura Isabel Olivero and Ana Gabriela Argüello
 last modification: 5/08/2023.
*/
#include <iostream>
#include <string>
#include <deque>
#include "habitacion.h"
using namespace std;
#ifndef __THE_FOREST_H
#define __THE_FOREST_H



class hotel{
        string adress;
        string name;
        int free_rooms;

        
    public:
        deque <Habitacion> rooms;
        hotel();
        hotel(string);
        int revi_dispo() const;
        void reserva_habitacion(int a);
        void mostrar_habitaciones();
        int checkout(int a);
        int ver_precio(int n);

};




#endif
